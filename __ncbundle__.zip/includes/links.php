<div id="links">
	<ul>
		<li><a href="/index.php">Home</a></li>
		<li><a href="/pages/Login.php">Login</a></li>
		<li><a href="/pages/Register.php">Register</a></li>
		<li><a href="/pages/About.php">About</a></li>
		<li><a href="/pages/feedback.php">Feedback</a></li>
		<li><a href="/pages/contactus.php">Contact Us</a></li>

		</ul>
</div><!-- end "links" container -->
			
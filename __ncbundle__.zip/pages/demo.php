<?php
require 'vendor/autoload.php';

$client = new MongoDB\Client;

//
// $result3 = $client->dropDatabase('newdb');
// var_dump($result3);

// list databases
// foreach ($client->listDatabases() as $db) {
//   var_dump($db);
// }



//
// $companydb = $client->newdb;
//
//
// $result2 = $companydb->createCollection('mynewcoll');
//
// var_dump($result2);
//
// foreach ($companydb->listCollections() as $collection) {
//   var_dump($collection);
// }
//
// $result2 = $companydb->createCollection('mycoll');
//
// var_dump($result2);

 ?>

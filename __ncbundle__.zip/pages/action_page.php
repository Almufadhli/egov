<?php



echo $_POST['uname'];
echo $_POST['psw'];


 ?>

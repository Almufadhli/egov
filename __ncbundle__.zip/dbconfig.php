<?php

require 'vendor/autoload.php';
$mongo = new MongoDB\Client;
$db = $mongo->egov;

 ?>

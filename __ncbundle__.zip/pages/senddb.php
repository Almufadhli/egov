<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Insert data to MONGODB</h1>
    <form action="insert.php" method="POST">
      NationalID: <input required type="text" name="nationalid" value="">
      Username: <input required type="text" name="username" value="">
      Password: <input required type="text" name="password" value="">
      <button type="submit" name="button">Send</button>
    </form>
  </body>
</html>
